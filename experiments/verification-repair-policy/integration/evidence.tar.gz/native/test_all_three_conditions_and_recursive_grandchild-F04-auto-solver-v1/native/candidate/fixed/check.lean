


theorem fixture_recursive : ∃ f : Nat → Nat, ∀ n, f n = n + 17 := by skip

