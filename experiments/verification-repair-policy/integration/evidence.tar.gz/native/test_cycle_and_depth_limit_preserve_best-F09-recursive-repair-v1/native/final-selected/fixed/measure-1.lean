import Lean

open Lean Elab Command in
elab "#refactor_eval " tag:str target:str cmd:command : command =>
  show CommandElabM Unit from do
    let name := target.getString.toName
    if (← getEnv).contains name then
      throwError "evaluation target already exists before candidate"
    let start ← IO.getNumHeartbeats
    elabCommand cmd
    let finish ← IO.getNumHeartbeats
    let env ← getEnv
    unless env.contains name do
      throwError "candidate did not define evaluation target"
    let axioms ← Lean.collectAxioms name
    let report := Json.mkObj [
      ("target", toJson target.getString),
      ("raw", toJson (finish - start)),
      ("scaled", toJson ((finish - start) / 1000)),
      ("axioms", toJson (axioms.toList.map Name.toString))]
    logInfo m!"REFACTOR_EVAL {tag.getString} {report.compress}"


set_option Elab.async false in
#refactor_eval "30723490c99f4180a97a92cb0b795e3a" "fixture_recursive"
theorem fixture_recursive : ∃ f : Nat → Nat, ∀ n, f n = n + 17 := by
  have h : ∀ n : Nat, (fun x => x + 17) n = n + 17 := by
    intro n
    rfl
  exact ⟨fun x => x + 17, h⟩

