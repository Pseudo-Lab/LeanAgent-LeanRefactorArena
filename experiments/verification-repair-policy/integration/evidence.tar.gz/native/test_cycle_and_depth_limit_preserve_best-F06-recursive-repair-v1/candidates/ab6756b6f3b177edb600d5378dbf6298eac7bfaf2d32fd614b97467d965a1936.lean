theorem fixture_cycle : True ∨ False := by
  apply Or.inr
