theorem fixture_cycle : True ∨ False := by exact Or.inl True.intro
