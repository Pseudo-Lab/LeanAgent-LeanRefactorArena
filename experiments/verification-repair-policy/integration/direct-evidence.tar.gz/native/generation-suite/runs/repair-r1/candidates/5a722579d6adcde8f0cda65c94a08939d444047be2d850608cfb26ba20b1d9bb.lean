theorem fixture_recursive : ∃ f : Nat → Nat, ∀ n, f n = n + 17 := by skip
                                                                     exact (by
                                                                       refine ⟨fun n => n + 17, ?_⟩
                                                                       skip
                                                                       exact (by
                                                                         simp
                                                                       )
                                                                     )
