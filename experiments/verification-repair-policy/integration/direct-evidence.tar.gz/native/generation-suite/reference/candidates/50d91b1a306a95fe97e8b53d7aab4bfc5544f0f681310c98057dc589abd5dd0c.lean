theorem fixture_recursive : ∃ f : Nat → Nat, ∀ n, f n = n + 17 := by
  have h : ∀ n : Nat, (fun x => x + 17) n = n + 17 := by
    intro n
    rfl
  exact ⟨fun x => x + 17, h⟩
