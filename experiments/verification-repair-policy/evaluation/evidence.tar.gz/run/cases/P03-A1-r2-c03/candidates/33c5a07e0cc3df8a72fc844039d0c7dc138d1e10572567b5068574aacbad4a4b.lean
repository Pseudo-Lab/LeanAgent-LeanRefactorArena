theorem InitsUpdatesComm
  {P : PureExpr} {σ σ' σ'' : SemanticStore P}
  {ks ks' : List P.Ident} {vs vs' : List P.Expr} :
  UpdateStates σ ks vs σ' →
  InitStates σ' ks' vs' σ'' →
  ∃ σ₁,
    σ₁ = (updatedStates σ ks' vs') ∧
    InitStates σ ks' vs' σ₁ ∧
    UpdateStates σ₁ ks vs σ'' := by
  intros Hup Hinit
  have hli := InitStatesLength Hinit
  have hlu := UpdateStatesLength Hup
  refine ⟨updatedStates σ ks' vs', rfl, ?_, ?_⟩
  · exact updatedStatesInit hli
      (UpdateStatesNotDefMonotone' (InitStatesNotDefined Hinit) Hup)
      (InitStatesNodup Hinit)
  · have hdis : ks'.Disjoint ks := by
      intro k hk' hk
      have hn := (InitStatesNotDefined Hinit) k hk'
      have hd := (UpdateStatesDefined Hup) k hk
      simpa [hn, Option.isSome] using hd
    have hcomm :
        updatedStates (updatedStates σ ks' vs') ks vs =
        updatedStates (updatedStates σ ks vs) ks' vs' := by
      unfold updatedStates
      apply updatedStatesComm
      rw [List.unzip_zip, List.unzip_zip] <;> simp_all
    rw [InitStatesUpdated Hinit, UpdateStatesUpdated Hup, ← hcomm]
    exact updatedStatesUpdate hlu
      (updatedStatesDefMonotone (UpdateStatesDefined' Hup))